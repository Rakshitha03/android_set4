package com.example.set4v1;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author lenovo
 */
public class Node {
    String key;
    Node link;
    public Node(String s)
    {
        this.key=s;
        this.link=null;
    }
    
}
