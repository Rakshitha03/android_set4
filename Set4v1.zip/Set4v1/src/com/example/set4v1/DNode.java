package com.example.set4v1;

public class DNode {
int info;
DNode right;
DNode left;
public DNode(int info)
    {
    this.info=info;
    this.right=null;
    this.left=null;
}
}