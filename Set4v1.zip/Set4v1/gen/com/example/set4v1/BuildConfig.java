/** Automatically generated file. DO NOT MODIFY */
package com.example.set4v1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}